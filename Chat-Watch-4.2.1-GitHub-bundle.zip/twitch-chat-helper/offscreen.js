const files={crystal:'sounds/01-crystal.mp3',sonar:'sounds/02-sonar.mp3',pulse:'sounds/03-pulse.mp3'};
// Keep active instances alive until they finish; separate detections can overlap.
const active=new Set();
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.target!=='sound-player')return false;
  if(!files[message.sound]){reply({ok:false,error:'Unknown sound'});return false;}
  const audio=new Audio(chrome.runtime.getURL(files[message.sound]));audio.volume=Math.max(0,Math.min(1,Number(message.volume)/100));active.add(audio);
  audio.addEventListener('ended',()=>active.delete(audio),{once:true});
  audio.play().then(()=>reply({ok:true})).catch(e=>{active.delete(audio);reply({ok:false,error:String(e)});});return true;
});
