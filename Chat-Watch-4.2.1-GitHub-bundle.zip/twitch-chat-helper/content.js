(() => {
  if (window.__twitchReportHelper) return;
  window.__twitchReportHelper = true;
  const D=globalThis.TwitchReportDetector, seen=new WeakMap(), nodesById=new Map(), scanSet=new Set();
  let state=null,pending=null,timer=null,observer=null,dead=false;
  const validLogin=x=>/^[a-z0-9_]{1,25}$/i.test(x||'');
  function currentChannel(){const p=location.pathname.split('/').filter(Boolean);return ((p[0]==='popout'||p[0]==='moderator')?p[1]:p[0]||'').toLowerCase();}
  function watched(){const c=currentChannel();return !!state&&(state.watchedChannels||[]).includes(c)&&!(state.pausedChannels||[]).includes(c);}
  async function request(message){
    if(dead)throw Error('Extension unavailable');
    try{if(!chrome.runtime?.id)throw Error('Extension context invalidated');const r=await chrome.runtime.sendMessage(message);if(!r?.ok)throw Error(r?.error||'Ошибка сохранения');return r;}
    catch(e){if(/context invalidated|Extension unavailable/i.test(String(e))){dead=true;observer?.disconnect();clearTimeout(timer);}throw e;}
  }
  function visible(el){const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none';}
  function loginOf(r){const x=r.login||r.name||'';return validLogin(x)?x.toLowerCase():null;}
  function nodeDetails(node){
    const n=node.querySelector('[data-a-target="chat-message-username"], .chat-author__display-name, .chat-line__username');
    const body=node.querySelector('[data-a-target="chat-line-message-body"], [data-a-target="chat-message-text"]');
    if(!n||!body)return null;
    return {name:(n.innerText||n.textContent||'').trim(),text:(body.innerText||body.textContent||'').trim(),login:(node.getAttribute('data-a-user')||n.getAttribute('data-a-user')||'').toLowerCase(),nameNode:n};
  }
  function locate(r){
    const login=loginOf(r);
    const matches=node=>{if(!node?.isConnected)return false;const d=nodeDetails(node);return d&&d.text===r.text&&(login&&d.login?d.login===login:d.name===r.name);};
    const cached=nodesById.get(r.id);if(matches(cached))return cached;
    const found=[...document.querySelectorAll('.chat-line__message,[data-a-target="chat-line-message"]')].filter(matches);return found.length===1?found[0]:null;
  }
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  async function openReportFor(r,draft){
    if(!r||r.channelName!==currentChannel())return {stage:'missing'};
    const node=locate(r),login=loginOf(r);if(!node||!login)return {stage:'notfound'};
    node.scrollIntoView({block:'center'});const before=new Set([...document.querySelectorAll('[role="dialog"],dialog')].filter(visible));
    const flags=[...node.querySelectorAll('button,[role="button"]')].filter(e=>visible(e)&&/report|пожалова|жалоб/i.test((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.getAttribute('data-a-target')||'')));
    if(flags.length===1){flags[0].click();await wait(500);}
    else {
      const details=nodeDetails(node);(details.nameNode.closest('[role="button"]')||details.nameNode).click();await wait(500);
      const cards=[...document.querySelectorAll('.viewer-card')].filter(visible).filter(c=>[...c.querySelectorAll('a[href]')].some(a=>{try{return new URL(a.href,location.href).pathname.toLowerCase()==='/'+login}catch{return false}}));
      if(cards.length!==1)return {stage:'notfound'};
      const card=cards[0],direct=[...card.querySelectorAll('button,[role="button"]')].filter(e=>visible(e)&&/^(report|report user|пожаловаться|пожаловаться на пользователя)$/i.test((e.innerText||e.getAttribute('aria-label')||'').trim()));
      if(direct.length===1)direct[0].click();else{
        const menus=[...card.querySelectorAll('button,[role="button"]')].filter(e=>visible(e)&&/^(more options|more|ещё|еще|дополнительно|другие действия)$/i.test((e.getAttribute('aria-label')||e.getAttribute('title')||'').trim()));
        if(menus.length!==1)return {stage:'card',message:'Текст скопирован. Карточка автора открыта: выберите «Пожаловаться» вручную.'};
        menus[0].click();await wait(300);
        const choices=[...document.querySelectorAll('[role="menuitem"], [role="menu"] button')].filter(e=>visible(e)&&/^(report|report user|пожаловаться|пожаловаться на пользователя)$/i.test((e.innerText||e.textContent||'').trim()));
        if(choices.length!==1)return {stage:'card',message:'Текст скопирован. Выберите «Пожаловаться» в меню автора вручную.'};choices[0].click();
      }await wait(500);
    }
    const fresh=[...document.querySelectorAll('[role="dialog"],dialog')].filter(e=>visible(e)&&!before.has(e)&&/report|жалоб|пожалова/i.test(e.innerText||''));
    if(fresh.length!==1)return {stage:'card',message:'Текст скопирован. Проверьте автора и завершите открытие жалобы вручную.'};
    pending={expires:Date.now()+120000,dialog:fresh[0],filled:false,category:D.category(r.text),categoryAttempted:false,text:draft?.recordId===r.id?draft.text:''};tryFill();
    return {stage:'opened',message:'Форма открыта. Проверьте автора, категорию и текст перед отправкой.'};
  }
  function tryFill(){
    if(!pending||Date.now()>pending.expires){pending=null;return;}const dialog=pending.dialog;if(!dialog?.isConnected||!visible(dialog))return;
    if(pending.category&&!pending.categoryAttempted){
      const labels=pending.category.key==='hate'?/^(hateful conduct|проявления ненависти|разжигание ненависти)$/i:/^(harassment|травля|преследование)$/i;
      const choices=[...dialog.querySelectorAll('button,[role="button"],[role="radio"],label')].filter(e=>visible(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&labels.test((e.innerText||e.textContent||'').trim().replace(/\s+/g,' ')));
      if(choices.length===1){pending.categoryAttempted=true;choices[0].click();}
    }
    if(pending.filled||!pending.text)return;const areas=[...dialog.querySelectorAll('textarea')].filter(a=>visible(a)&&!a.disabled&&!a.readOnly&&!a.value);
    if(areas.length!==1)return;const a=areas[0];Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(a,pending.text);a.dispatchEvent(new Event('input',{bubbles:true}));a.dispatchEvent(new Event('change',{bubbles:true}));pending.filled=true;
  }
  chrome.runtime.onMessage.addListener((req,sender,sendResponse)=>{
    if(req.target!=='report-helper')return false;
    if(req.action==='ping'){sendResponse({channel:currentChannel(),paused:!watched()});return false;}
    if(req.action!=='openReport')return false;
    request({type:'get'}).then(x=>openReportFor((x.state.recent.find(r=>r.id===req.recordId)||(x.state.pendingReview||[]).find(r=>r.id===req.recordId)),x.state.draft)).then(sendResponse).catch(()=>sendResponse({stage:'missing'}));return true;
  });
  function inspect(node){
    if(!watched()||!node||node.nodeType!==1)return;
    const d=nodeDetails(node);if(!d?.name||!d.text)return;
    const signature=d.name+'\n'+d.text;if(seen.get(node)===signature)return;seen.set(node,signature);if(!D.candidate(d.text))return;
    const channelName=currentChannel(),login=validLogin(d.login)?d.login:null;
    const item={id:crypto.randomUUID(),name:d.name,login,text:d.text,channelName,channel:'https://www.twitch.tv/'+channelName,detectedAt:Date.now()};
    request({type:'add',item}).then(result=>{if(!result.ignored)nodesById.set(result.id,node);}).catch(()=>{});
  }
  function enqueue(el){if(el&&el.nodeType===1){const closest=el.closest('.chat-line__message,[data-a-target="chat-line-message"]');if(closest)scanSet.add(closest);el.querySelectorAll?.('.chat-line__message,[data-a-target="chat-line-message"]').forEach(x=>scanSet.add(x));}}
  function flush(){timer=null;for(const n of scanSet)inspect(n);scanSet.clear();tryFill();}
  function queueScan(node){enqueue(node);if(!timer)timer=setTimeout(flush,120);}
  observer=new MutationObserver(mutations=>{for(const m of mutations){enqueue(m.target.nodeType===1?m.target:m.target.parentElement);for(const n of m.addedNodes)enqueue(n);}if(!timer)timer=setTimeout(flush,120);});
  observer.observe(document.body,{childList:true,subtree:true,characterData:true});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.reportHelperData){state=changes.reportHelperData.newValue;}});
  request({type:'get'}).then(x=>{state=x.state;queueScan(document.body);}).catch(()=>{});
})();
