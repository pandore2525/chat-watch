const $=s=>document.querySelector(s);
const tabNames={monitor:'Мониторинг',history:'История',settings:'Настройки',publication:'Публикация'};
let lastTab='monitor';
function selectTab(name,focus=false){
 if(!tabNames[name]||(name==='publication'&&$('#tab-publication').hidden))return;
 lastTab=name;$('#pending-panel').hidden=true;$('#pending-toggle').setAttribute('aria-expanded','false');
 for(const key of Object.keys(tabNames)){const selected=key===name;$('#tab-'+key).setAttribute('aria-selected',String(selected));$('#tab-'+key).tabIndex=selected?0:-1;$('#view-'+key).hidden=!selected;}
 $('#page-title').textContent=tabNames[name];document.body.scrollTo({top:0,behavior:'instant'});document.documentElement.scrollTo({top:0,behavior:'instant'});if(focus)$('#tab-'+name).focus();
}
for(const tab of document.querySelectorAll('[role=tab]')){tab.addEventListener('click',()=>selectTab(tab.id.slice(4)));tab.addEventListener('keydown',e=>{const names=Object.keys(tabNames).filter(k=>!$('#tab-'+k).hidden);let index=names.indexOf(tab.id.slice(4));if(e.key==='ArrowRight')index=(index+1)%names.length;else if(e.key==='ArrowLeft')index=(index+names.length-1)%names.length;else if(e.key==='Home')index=0;else if(e.key==='End')index=names.length-1;else return;e.preventDefault();selectTab(names[index],true);});}


// Animate history cards once when they first scroll into view, never hide their content.
const motionReduced=matchMedia('(prefers-reduced-motion: reduce)');
const revealedHistory=new Set();
const historyObserver='IntersectionObserver' in window ? new IntersectionObserver(entries=>{
 for(const entry of entries){
  if(!entry.isIntersecting)continue;const el=entry.target,key=el.dataset.revealKey;
  historyObserver.unobserve(el);if(!key||revealedHistory.has(key))continue;
  revealedHistory.add(key);if(revealedHistory.size>300)revealedHistory.delete(revealedHistory.values().next().value);
  if(!motionReduced.matches)el.classList.add('scroll-reveal');
 }
},{threshold:0.12}) : null;
// Animate pending cards independently as they enter the viewport.
const revealedPending=new Set();
const pendingObserver='IntersectionObserver' in window ? new IntersectionObserver(entries=>{
 for(const entry of entries){
  if(!entry.isIntersecting)continue;const el=entry.target,key=el.dataset.revealKey;
  pendingObserver.unobserve(el);if(!key||revealedPending.has(key))continue;
  revealedPending.add(key);if(revealedPending.size>300)revealedPending.delete(revealedPending.values().next().value);
  if(!motionReduced.matches)el.classList.add('scroll-reveal');
 }
},{threshold:0.12}) : null;
const sectionObserver='IntersectionObserver' in window ? new IntersectionObserver(entries=>{
 for(const entry of entries){if(!entry.isIntersecting)continue;sectionObserver.unobserve(entry.target);if(!motionReduced.matches)entry.target.classList.add('scroll-reveal');}
},{threshold:0.12}) : null;
document.querySelectorAll('.watch-panel,.sound-panel,.breakdown').forEach(el=>sectionObserver?.observe(el));

let state=null, channelStatus={};
function request(message){return chrome.runtime.sendMessage(message).then(r=>{if(!r?.ok)throw Error(r?.error||'Ошибка сохранения');return r.state;});}
function loginOf(r){const x=r.login||r.name||'';return /^[a-z0-9_]{1,25}$/i.test(x)?x.toLowerCase():null;}
function report(r){return `Прошу проверить сообщение пользователя ${r.name} в чате Twitch.\n\nСообщение: «${r.text}»\n\nВозможно, оно содержит оскорбительные выражения. Пожалуйста, оцените контекст и соответствие правилам Twitch.\nКанал: ${r.channel}\nВремя обнаружения: ${new Date(r.detectedAt).toLocaleString()}`;}
function show(s){
 state=s;renderWatched();renderPending();const settings=s.settings||{sound:'off',volume:50};$('#desktop-notifications').checked=settings.desktopNotifications!==false;$('#sound').value=settings.sound;if(document.activeElement!==$('#volume'))$('#volume').value=String(settings.volume);$('#volume-value').textContent=$('#volume').value+'%';if($('#sound-status').textContent==='Выберите звук для новых находок.')$('#sound-status').textContent=settings.sound==='off'?'Выберите звук для новых находок.':'Звук включён для новых находок.';$('#total').textContent=String(s.total);$('#saved').textContent=String(s.recent.length);
 const channels=$('#channels');channels.replaceChildren();const entries=Object.entries(s.byChannel).sort((a,b)=>b[1]-a[1]);
 if(!entries.length){const el=document.createElement('p');el.className='empty';el.textContent='Пока нет данных';channels.append(el)}else for(const [name,count] of entries){let el=document.createElement('span');el.className='channel';el.textContent=`${name} · ${count}`;channels.append(el)}
 const draft=$('#draft-section');draft.hidden=!s.draft;$('#goto-draft').hidden=!s.draft;$('#tab-publication').hidden=!s.draft;if(!s.draft&&$('#tab-publication').getAttribute('aria-selected')==='true')selectTab('history');
 const draftRecord=s.draft ? [...(s.pendingReview||[]),...(s.recent||[])].find(r=>r.id===s.draft.recordId) : null;
 const sources=Array.isArray(draftRecord?.sources)?draftRecord.sources:[];
 $('#chatterino-warning').hidden=!(sources.includes('chatterino')&&!sources.includes('twitch'));
 if(s.draft && document.activeElement!==$('#draft'))$('#draft').value=s.draft.text;
 const list=$('#recent');historyObserver?.disconnect();list.replaceChildren();if(!s.recent.length){const el=document.createElement('p');el.className='empty';el.textContent='Новых совпадений пока нет.';list.append(el);return;}
 for(const r of s.recent){const el=document.createElement('article');el.className='item';const top=document.createElement('div');top.className='item-top';const name=document.createElement('strong');name.textContent=r.name;const recovered=document.createElement('span');recovered.className='hint';recovered.textContent=r.recovered?'Восстановлено':'';top.append(name,recovered);const meta=document.createElement('div');meta.className='meta';meta.textContent=`${r.channelName} · ${new Date(r.detectedAt).toLocaleString()}`;const sources=document.createElement('div');sources.className='meta';sources.textContent=(r.sources||[]).length?'Источники: '+r.sources.map(v=>v==='chatterino'?'Chatterino+':'Twitch').join(' · '):'';const text=document.createElement('p');text.className='message';text.textContent=r.text;const row=document.createElement('div');row.className='row';const create=document.createElement('button');create.className='primary';create.textContent='Подготовить текст';create.onclick=()=>prepareRecord(r);const login=loginOf(r);const link=document.createElement(login?'a':'span');link.className=login?'link':'hint';link.textContent=login?'Профиль автора':'Логин автора неизвестен';if(login){link.href='https://www.twitch.tv/'+login;link.target='_blank';link.rel='noopener noreferrer';}const del=document.createElement('button');del.className='secondary';del.textContent='Удалить из истории';del.onclick=()=>request({type:'remove',id:r.id}).catch(()=>$('#status').textContent='Не удалось удалить запись.');row.append(create,link,del);el.append(top,meta,sources,text,row);el.dataset.revealKey=String(r.id);list.append(el);if(!revealedHistory.has(String(r.id)))historyObserver?.observe(el);}
}


async function prepareRecord(r){
 try{const next=await request({type:'saveDraft',draft:{recordId:r.id,text:report(r)}});show(next);selectTab('publication');$('#status').textContent='Черновик сохранён.';}
 catch(e){$('#status').textContent='Не удалось сохранить черновик.';}
}
function renderPending(){
 const records=state?.pendingReview||[];$('#pending-count').textContent=String(records.length);
 const list=$('#pending-list');pendingObserver?.disconnect();list.replaceChildren();
 if(!records.length){const p=document.createElement('p');p.className='empty';p.textContent='Нет находок, ожидающих проверки.';list.append(p);return;}
 for(const r of records){
  const el=document.createElement('article');el.className='pending-item';const top=document.createElement('div');top.className='pending-item-top';
  const identity=document.createElement('div');identity.className='pending-identity';const name=document.createElement('strong');name.textContent=r.name;const meta=document.createElement('span');meta.className='meta';meta.textContent=r.channelName+' · '+new Date(r.detectedAt).toLocaleString();identity.append(name,meta);
  const dismiss=document.createElement('button');dismiss.className='dismiss-pending';dismiss.type='button';dismiss.title='Убрать из проверки, оставить в истории';dismiss.setAttribute('aria-label','Не отправлять жалобу на '+r.name+'; убрать из проверки');
  dismiss.innerHTML='<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M6.2 3.5a2.2 2.2 0 0 1 3.1 0L16 10.2l6.7-6.7a2.2 2.2 0 0 1 3.1 0l2.7 2.7a2.2 2.2 0 0 1 0 3.1L21.8 16l6.7 6.7a2.2 2.2 0 0 1 0 3.1l-2.7 2.7a2.2 2.2 0 0 1-3.1 0L16 21.8l-6.7 6.7a2.2 2.2 0 0 1-3.1 0l-2.7-2.7a2.2 2.2 0 0 1 0-3.1L10.2 16 3.5 9.3a2.2 2.2 0 0 1 0-3.1z" fill="currentColor" stroke="#48343e" stroke-width="1.4" stroke-linejoin="round"/></svg>';
  dismiss.onclick=()=>request({type:'markReviewed',id:r.id}).catch(()=>$('#status').textContent='Не удалось убрать запись из проверки.');top.append(identity,dismiss);
  const text=document.createElement('p');text.className='message';text.textContent=r.text;const actions=document.createElement('div');actions.className='row';
  const prepare=document.createElement('button');prepare.className='primary';prepare.textContent='Подготовить текст';prepare.onclick=()=>prepareRecord(r);
  const login=loginOf(r);const link=document.createElement(login?'a':'span');link.className=login?'link':'hint';link.textContent=login?'Профиль автора':'Логин автора неизвестен';if(login){link.href='https://www.twitch.tv/'+login;link.target='_blank';link.rel='noopener noreferrer';}
  actions.append(prepare,link);el.append(top,text,actions);el.dataset.revealKey=String(r.id);list.append(el);if(!revealedPending.has(String(r.id)))pendingObserver?.observe(el);
 }
}
function openPending(){
 if(!$('#pending-panel').hidden){selectTab(lastTab==='publication'&&$('#tab-publication').hidden?'history':lastTab);return;}
 for(const key of Object.keys(tabNames)){$('#tab-'+key).setAttribute('aria-selected','false');$('#tab-'+key).tabIndex=-1;$('#view-'+key).hidden=true;}
 $('#pending-panel').hidden=false;$('#pending-toggle').setAttribute('aria-expanded','true');$('#page-title').textContent='Ожидает проверки';document.body.scrollTo({top:0,behavior:'instant'});document.documentElement.scrollTo({top:0,behavior:'instant'});
}
$('#pending-toggle').onclick=openPending;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#pending-panel').hidden){openPending();$('#pending-toggle').focus();}});

function renderWatched(){
 const list=$('#watched-list');list.replaceChildren();const watched=state?.watchedChannels||[];
 if(!watched.length){const p=document.createElement('p');p.className='empty';p.textContent='Добавьте каналы, которые нужно отслеживать.';list.append(p);return;}
 for(const name of watched){
  const item=document.createElement('div');item.className='watch-item';const info=document.createElement('div');info.className='watch-info';
  const label=document.createElement('span');label.className='watch-name';label.textContent=name;
  const status=document.createElement('span');status.className='watch-state';status.textContent=channelStatus[name]||'Проверка вкладки…';info.append(label,status);
  const actions=document.createElement('div');actions.className='watch-actions';
  const open=document.createElement('button');open.textContent='Открыть стрим';open.title='Открыть страницу трансляции';open.onclick=()=>openStream(name);
  const paused=(state.pausedChannels||[]).includes(name);const pause=document.createElement('button');pause.textContent=paused?'Продолжить':'Пауза';pause.title=paused?'Возобновить мониторинг':'Приостановить мониторинг';pause.onclick=async()=>{try{await request({type:'setChannelPaused',name,paused:!paused});await refreshChannels();}catch{$('#watch-feedback').textContent='Не удалось изменить состояние мониторинга.';}};
  const remove=document.createElement('button');remove.type='button';remove.className='trash-button';remove.title='Убрать канал из мониторинга';remove.setAttribute('aria-label','Убрать канал '+name+' из мониторинга');remove.innerHTML='<svg class="trash-closed" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M8 4V3.4C8 2.6 8.6 2 9.4 2h5.2c.8 0 1.4.6 1.4 1.4V4h3.2c1 0 1.8.8 1.8 1.8V7H3V5.8C3 4.8 3.8 4 4.8 4H8z"/><path fill="currentColor" fill-rule="evenodd" d="M4.1 8h15.8l-.9 11.7c-.1 1.3-1.1 2.3-2.4 2.3H7.4C6.1 22 5.1 21 5 19.7L4.1 8zm4.3 2.5a.8.8 0 0 1 .8.7l.4 7.4a.8.8 0 0 1-1.6.1l-.4-7.4a.8.8 0 0 1 .8-.8zm3.6-.1a.8.8 0 0 1 .8.8v7.4a.8.8 0 0 1-1.6 0v-7.4a.8.8 0 0 1 .8-.8zm3.6.1a.8.8 0 0 1 .8.8l-.4 7.4a.8.8 0 0 1-1.6-.1l.4-7.4a.8.8 0 0 1 .8-.7z"/></svg><svg class="trash-open" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M5.7 2.8 20 6.2c.9.2 1.5 1.1 1.3 2l-.2.9L3.2 4.8l.2-.9c.3-.9 1.2-1.4 2.3-1.1z"/><path fill="none" stroke="currentColor" stroke-width="1.4" d="m9.1 3.5.3-1.2c.2-.8.8-1.2 1.6-1l5.1 1.2c.7.2 1.1.9.9 1.6l-.3 1.2"/><path fill="currentColor" fill-rule="evenodd" d="M4.1 8.8h15.8L19 20c-.1 1.1-1 2-2.2 2H7.2C6 22 5.1 21.1 5 20L4.1 8.8zm4.3 1.8a.8.8 0 0 1 .8.7l.4 7.4a.8.8 0 0 1-1.6.1l-.4-7.4a.8.8 0 0 1 .8-.8zm3.6-.1a.8.8 0 0 1 .8.8v7.4a.8.8 0 0 1-1.6 0v-7.4a.8.8 0 0 1 .8-.8zm3.6.1a.8.8 0 0 1 .8.8l-.4 7.4a.8.8 0 0 1-1.6-.1l.4-7.4a.8.8 0 0 1 .8-.7z"/></svg>';remove.onclick=async()=>{try{await request({type:'unwatchChannel',name});}catch{$('#watch-feedback').textContent='Не удалось обновить список.';}};
  actions.append(open,pause,remove);item.append(info,actions);list.append(item);
 }
}
async function refreshChannels(){
 try{
  const reply=await chrome.runtime.sendMessage({type:'getMonitorStatus'});
  if(!reply?.ok)throw Error('Нет ответа');
  const labels={connected:'Чат подключён · работает в фоне',connecting:'Подключение к чату…',reconnecting:'Переподключение…',paused:'Мониторинг на паузе',closed:'Вкладка не открыта',unavailable:'Нет подключения · проверяется вкладка'};
  channelStatus=Object.fromEntries(Object.entries(reply.channels).map(([name,value])=>[name,labels[value]||'Проверка…']));renderWatched();
 }catch{$('#watch-feedback').textContent='Не удалось проверить подключение.';}
}

async function openStream(name){
 try{
  const tabs=await chrome.tabs.query({url:['https://www.twitch.tv/*','https://m.twitch.tv/*']});
  const existing=tabs.find(t=>{try{const u=new URL(t.url);const p=u.pathname.toLowerCase().split('/').filter(Boolean);return p.length===1&&p[0]===name;}catch{return false;}});
  if(existing){await chrome.tabs.update(existing.id,{active:true});await chrome.windows.update(existing.windowId,{focused:true});}
  else await chrome.tabs.create({url:'https://www.twitch.tv/'+name,active:true});
 }catch{$('#watch-feedback').textContent='Не удалось открыть стрим.';}
}
async function openChannel(name){
 try{
  const tabs=await chrome.tabs.query({url:['https://www.twitch.tv/*','https://m.twitch.tv/*']});
  const existing=tabs.find(t=>{try{const p=new URL(t.url).pathname.toLowerCase().split('/').filter(Boolean);return (p[0]==='popout'||p[0]==='moderator'?p[1]:p[0])===name;}catch{return false;}});
  if(existing){await chrome.tabs.update(existing.id,{active:true});await chrome.windows.update(existing.windowId,{focused:true});}
  else {await chrome.tabs.create({url:'https://www.twitch.tv/popout/'+name+'/chat',active:false});$('#watch-feedback').textContent='Чат '+name+' открыт в фоновой вкладке.';setTimeout(refreshChannels,3000);}
 }catch{$('#watch-feedback').textContent='Не удалось открыть вкладку чата.';}
}
$('#watch-form').addEventListener('submit',async e=>{
 e.preventDefault();const name=$('#watch-input').value.trim().replace(/^@/,'').toLowerCase();
 if(!/^[a-z0-9_]{1,25}$/.test(name)){$('#watch-feedback').textContent='Введите логин Twitch: буквы, цифры и подчёркивание.';return;}
 try{await request({type:'watchChannel',name});$('#watch-input').value='';await openChannel(name);await refreshChannels();}catch(e){$('#watch-feedback').textContent='Не удалось добавить канал. Лимит — 20.';}
});
$('#desktop-notifications').addEventListener('change',async e=>{try{await request({type:'settings',settings:{desktopNotifications:e.target.checked}});}catch{$('#watch-feedback').textContent='Не удалось сохранить настройки уведомлений.';}});
setInterval(refreshChannels,5000);
const soundFiles={crystal:'sounds/01-crystal.mp3',sonar:'sounds/02-sonar.mp3',pulse:'sounds/03-pulse.mp3'};
async function saveSound(){try{await request({type:'settings',settings:{sound:$('#sound').value,volume:Number($('#volume').value)}});$('#sound-status').textContent=$('#sound').value==='off'?'Звук выключен.':'Звук включён для новых находок.';}catch{$('#sound-status').textContent='Не удалось сохранить настройки.';}}
$('#sound').addEventListener('change',saveSound);
$('#volume').addEventListener('input',()=>{$('#volume-value').textContent=$('#volume').value+'%';});
$('#volume').addEventListener('change',saveSound);
$('#preview-sound').onclick=async()=>{const f=soundFiles[$('#sound').value];if(!f){$('#sound-status').textContent='Сначала выберите вариант звука.';return;}try{const a=new Audio(chrome.runtime.getURL(f));a.volume=Number($('#volume').value)/100;await a.play();$('#sound-status').textContent=a.volume?'Воспроизводится пример.':'Громкость равна нулю.';}catch{$('#sound-status').textContent='Не удалось воспроизвести звук.';}};
$('#goto-draft').onclick=()=>selectTab('publication');
$('#draft').addEventListener('input',()=>{if(!state?.draft)return;const draft={...state.draft,text:$('#draft').value};request({type:'saveDraft',draft}).catch(()=>$('#status').textContent='Не удалось сохранить текст.');});
let copyConfirmRecordId=null;
$('#copy-draft').onclick=()=>{if(!state?.draft)return;copyConfirmRecordId=state.draft.recordId;$('#confirm-copy-source-warning').hidden=$('#chatterino-warning').hidden;$('#confirm-copy').showModal();$('#confirm-copy-no').focus();};
$('#confirm-copy-no').onclick=()=>$('#confirm-copy').close();
$('#confirm-copy-yes').onclick=async()=>{$('#confirm-copy').close();if(!state?.draft||state.draft.recordId!==copyConfirmRecordId){$('#status').textContent='Черновик изменился. Проверьте его и повторите действие.';return;}try{await navigator.clipboard.writeText($('#draft').value);}catch{$('#draft').focus();$('#draft').select();$('#status').textContent='Нажмите Ctrl+C, чтобы скопировать.';return;}try{if(state?.draft)await request({type:'saveDraft',draft:{...state.draft,text:$('#draft').value}});const result=await chrome.runtime.sendMessage({type:'openReport',recordId:state?.draft?.recordId,clearDraftAfterCopy:true,expectedDraftText:$('#draft').value});$('#status').textContent=result?.message||'Текст скопирован. Откройте жалобу вручную.';}catch{$('#status').textContent='Текст скопирован. Откройте жалобу вручную.'}};
$('#delete-draft').onclick=()=>request({type:'saveDraft',draft:null}).catch(()=>$('#status').textContent='Не удалось удалить черновик.');
$('#clear').onclick=()=>{$('#confirm').hidden=false;$('#clear').hidden=true};$('#cancel-clear').onclick=()=>{$('#confirm').hidden=true;$('#clear').hidden=false};$('#confirm-clear').onclick=async()=>{try{await request({type:'clear'});$('#confirm').hidden=true;$('#clear').hidden=false;$('#status').textContent='История, статистика и черновик очищены.'}catch{$('#status').textContent='Не удалось очистить данные.'}};
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.reportHelperData)show(changes.reportHelperData.newValue)});
request({type:'get'}).then(s=>{show(s);refreshChannels();}).catch(()=>{$('#status').textContent='Не удалось загрузить сохранённые данные.'});

async function refreshChatterino(){
 try{const r=await chrome.runtime.sendMessage({type:'chatterinoStatus'});const labels={disabled:'Мост отключён',connecting:'Подключаем локальный мост…',active:'Мост подключён · Chatterino+ активен',stale:'Мост подключён, но файл не обновляется: проверьте Chatterino+ и плагин', 'feed-missing':'Мост подключён, но файл не найден: запустите Chatterino+ и плагин', 'feed-error':'Мост подключён, но файл временно не читается', 'host-error':'Мост недоступен: проверьте установку и ID расширения'};$('#cw-status').textContent=labels[r?.status]||'Не удалось проверить мост';if(r?.status==='active'&&Number.isInteger(r.active))$('#cw-status').textContent='Мост подключён · чатов в Chatterino+: '+r.active;}
 catch{$('#cw-status').textContent='Не удалось проверить мост';}
}
$('#cw-connect').onclick=async()=>{await chrome.runtime.sendMessage({type:'cwNativeToggle',enabled:true});await refreshChatterino();};
$('#cw-disconnect').onclick=async()=>{await chrome.runtime.sendMessage({type:'cwNativeToggle',enabled:false});await refreshChatterino();};
$('#cw-copy-id').onclick=async()=>{try{await navigator.clipboard.writeText(chrome.runtime.id);$('#cw-status').textContent='ID скопирован. Вставьте его при установке моста.';}catch{$('#cw-status').textContent='ID: '+chrome.runtime.id;}};
setInterval(refreshChatterino,5000);refreshChatterino();
