/* Matches are review candidates, never conclusions about policy violations. */
(() => {
  const visualMap={a:'а',b:'в',c:'с',e:'е',h:'н',i:'и',k:'к',m:'м',o:'о',p:'р',t:'т',x:'х',y:'у',d:'д',g:'г',n:'н',r:'р','0':'о','1':'и','3':'е','4':'ч'};
  const latinMap={a:'а',b:'б',c:'к',d:'д',e:'е',f:'ф',g:'г',h:'х',i:'и',j:'й',k:'к',l:'л',m:'м',n:'н',o:'о',p:'п',q:'к',r:'р',s:'с',t:'т',u:'у',v:'в',w:'в',x:'кс',y:'ы',z:'з','0':'о','1':'и','3':'е','4':'ч'};
  const clean=s=>s.normalize('NFKC').toLowerCase().replace(/[\u200b-\u200f\u202a-\u202e\u2060\ufeff]/g,'');
  const normalize=s=>clean(s).replace(/[a-z0-9]/g,c=>visualMap[c]||c);
  const transliterate=s=>clean(s).replace(/shch|sch|zh|kh|ch|sh|yu|ya|yo/g,x=>({shch:'щ',sch:'щ',zh:'ж',kh:'х',ch:'ч',sh:'ш',yu:'ю',ya:'я',yo:'ё'}[x])).replace(/[a-z0-9]/g,c=>latinMap[c]||c);
  const exact=new Set(['пид','пидо','пида','пидр','нег','негр','педик','педики','чурк','чурка','хач','хохл','хохол','москал','москаль','жид','цыган']);
  const inflected=/^(?:(?:пид[оа]р|пидр|негр)[\p{L}]*|педик(?:а|у|и|ов|ом|е|ам|ами|ах)?|чурк(?:а|и|у|ой|ою|е|ам|ами|ах)|хач(?:а|у|и|ей|ом|е|ам|ами|ах|ик|ики|иков)?|хохол|хохл(?:а|у|ы|ов|ом|е|ам|ами|ах)|москал(?:ь|я|ю|и|ей|ем|е|ям|ями|ях)|жид(?:а|у|ы|ов|ом|е|ам|ами|ах)?|цыган(?:а|у|ы|ов|ом|е|ам|ами|ах|ка|ки|ку|кой|ке)?)$/u;
  function parts(text){
    const n=clean(text);const words=n.match(/[\p{L}\p{N}]+/gu)||[];const variants=[...words];
    for(const chunk of n.match(/[\p{L}\p{N}]+(?:[.\-_*•·]+[\p{L}\p{N}]+)+/gu)||[]) variants.push(chunk.replace(/[.\-_*•·]+/g,''));
    for(let i=0;i<words.length;i++){if(words[i].length!==1)continue;let joined=words[i];for(let j=i+1;j<Math.min(i+10,words.length)&&words[j].length===1;j++){joined+=words[j];variants.push(joined);}}
    return variants;
  }
  function candidate(text){return parts(text).some(raw=>[normalize(raw),transliterate(raw)].some(w=>exact.has(w)||inflected.test(w)));}
  function category(text){
    const t=normalize(text);
    if (/[«»"“”‘’]|(?:^|[^\p{L}])(?:тест|пример|цитат\p{L}*|слово|называ\p{L}*|нельзя|запрещен\p{L}*|не\s+говор\p{L}*)(?:$|[^\p{L}])/u.test(t)) return null;
    const group=/(?:негр\p{L}*|черн[ыо]\p{L}*|чернокож\p{L}*|африкан\p{L}*|гомосексуал\p{L}*|лгбт)/u.test(t);
    const hostility=/(?:ненавиж\p{L}*|недолюд\p{L}*|убить|убива\p{L}*|сдохн\p{L}*|истреб\p{L}*|уничтож\p{L}*)/u.test(t);
    if(group&&hostility)return {key:'hate',label:'Проявления ненависти / Hateful Conduct',reason:'Упомянута группа людей и явная враждебность. Это предварительная оценка.'};
    const directed=/(?:^|[^\p{L}])(?:ты|тебя|тебе|твой|твоя)(?:$|[^\p{L}])/u.test(t)||/@[\p{L}\p{N}_]+/u.test(t);
    const slur=/(?:пид[оа]р\p{L}*|пидр\p{L}*)/u.test(t);
    if(!group&&directed&&slur)return {key:'harassment',label:'Травля / Harassment',reason:'Есть оскорбление, направленное на собеседника. Проверьте, не относится ли оно к признакам ненависти.'};
    return null;
  }
  globalThis.TwitchReportDetector={candidate,normalize,category};
})();
