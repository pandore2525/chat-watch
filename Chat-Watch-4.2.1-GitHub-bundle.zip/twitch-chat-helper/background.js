importScripts('detector.js');
// All writes are serialized here so concurrent Twitch tabs cannot overwrite each other.
const KEY='reportHelperData';
let queue=Promise.resolve();
const seed=()=>({version:1,total:0,byChannel:{},recent:[],pendingReview:[],watchedChannels:[],pausedChannels:[],panelHidden:[],settings:{sound:'off',volume:50,desktopNotifications:false},draft:null});
async function read(){const obj=await chrome.storage.local.get(KEY);if(obj[KEY]){const state=obj[KEY];if(!state.settings){state.settings={sound:'off',volume:50};await chrome.storage.local.set({[KEY]:state});}return state;}const state=seed();await chrome.storage.local.set({[KEY]:state});return state;}
let creatingAudio;
async function playSound(settings){
  if(!settings || settings.sound==='off' || !settings.volume)return;
  if(!chrome.offscreen)throw Error('В этом браузере звуковые уведомления не поддерживаются');
  const exists=chrome.offscreen.hasDocument ? await chrome.offscreen.hasDocument() : (await clients.matchAll()).some(c=>c.url===chrome.runtime.getURL('offscreen.html'));
  if(!exists){
    if(!creatingAudio) creatingAudio=chrome.offscreen.createDocument({url:'offscreen.html',reasons:['AUDIO_PLAYBACK'],justification:'Звуковой сигнал при обнаружении сообщения в чате.'});
    try { await creatingAudio; } finally { creatingAudio=null; }
  }
  const response=await chrome.runtime.sendMessage({target:'sound-player',sound:settings.sound,volume:settings.volume});
  if(!response?.ok)throw Error(response?.error||'Нет ответа звукового модуля');
}
const batches=new Map();
async function notifyFinding(item,settings){
  if(settings?.desktopNotifications===false)return;
  const name=String(item.channelName||'').toLowerCase();if(!/^[a-z0-9_]{1,25}$/.test(name))return;
  const now=Date.now(),old=batches.get(name);const n=old&&now-old.at<10000?old.n+1:1;batches.set(name,{at:now,n});
  const message=n===1?('Автор: '+item.name+'. Откройте историю для проверки.'):(n+' новых совпадений за последние секунды. Откройте историю для проверки.');
  try{await chrome.notifications.create('channel:'+name,{type:'basic',iconUrl:'icons/icon128.png',title:'Совпадение в чате: '+name,message,silent:true});}catch(e){console.warn('Уведомление не показано:',e.message);}
}
chrome.notifications.onClicked.addListener(async id=>{
  const match=/^channel:([a-z0-9_]{1,25})$/.exec(id);if(!match)return;
  const name=match[1];try{
    const tabs=await chrome.tabs.query({url:['https://www.twitch.tv/*','https://m.twitch.tv/*']});
    const tab=tabs.find(t=>{try{const p=new URL(t.url).pathname.toLowerCase().split('/').filter(Boolean);return (p[0]==='popout'||p[0]==='moderator'?p[1]:p[0])===name;}catch{return false;}});
    if(tab){await chrome.tabs.update(tab.id,{active:true});await chrome.windows.update(tab.windowId,{focused:true});}
    else await chrome.tabs.create({url:'https://www.twitch.tv/popout/'+name+'/chat'});
  }catch(e){console.warn('Не удалось открыть чат:',e.message);}
});
function retainPendingInHistory(state,id){
  const r=(state.pendingReview||[]).find(x=>x.id===id);
  if(r&&!state.recent.some(x=>x.id===id)){state.recent.unshift(structuredClone(r));state.recent=state.recent.slice(0,100);}
}
async function processRequest(req){
  const state=await read();
  if(req.type==='get')return {ok:true,state};
  if(req.type==='add'){
    const x=req.item;
    if(!x || typeof x.name!=='string' || typeof x.text!=='string' || !/^https:\/\/(www|m)\.twitch\.tv\//i.test(x.channel||''))throw Error('Некорректная запись');
    if(!(state.watchedChannels||[]).includes(x.channelName)||(state.pausedChannels||[]).includes(x.channelName))return {ok:true,id:x.id,ignored:true,state};
    // Twitch IDs distinguish repeated messages; the fallback links the same DOM/IRC message.
    const existing=[...state.recent,...(state.pendingReview||[])].find(r=>{
      if(r.channelName!==x.channelName)return false;
      if(r.messageId&&x.messageId)return r.messageId===x.messageId;
      const sameUser=r.login&&x.login?r.login.toLowerCase()===x.login.toLowerCase():r.name.toLowerCase()===x.name.toLowerCase();
      return sameUser&&r.text===x.text&&Math.abs(x.detectedAt-r.detectedAt)<120000;
    });
    const source=x.source==='chatterino'?'chatterino':'twitch';
    if(existing){let changed=false;if(x.messageId&&!existing.messageId){existing.messageId=x.messageId;changed=true;}
      if(!(existing.sources||[]).includes(source)){existing.sources=[...new Set([...(existing.sources||[]),source])];changed=true;}
      if(changed){for(const copy of [...state.recent,...(state.pendingReview||[])])if(copy.id===existing.id){if(existing.messageId)copy.messageId=existing.messageId;copy.sources=[...(existing.sources||[])];}await chrome.storage.local.set({[KEY]:state});}return {ok:true,id:existing.id,state};}
    x.sources=[source];delete x.source;
    state.recent.unshift(x);state.recent=state.recent.slice(0,100);state.pendingReview=[structuredClone(x),...(state.pendingReview||[])];state.panelHidden=(state.panelHidden||[]).filter(id=>state.recent.some(r=>r.id===id));state.total++;state.byChannel[x.channelName]=(state.byChannel[x.channelName]||0)+1;
    await chrome.storage.local.set({[KEY]:state});playSound(state.settings).catch(e=>console.warn('Звук не воспроизведён:',e.message));await notifyFinding(x,state.settings);return {ok:true,id:x.id,state};
  }
  if(req.type==='settings'){
    const old=state.settings||{sound:'off',volume:50}, patch=req.settings||{};
    const sound=['off','crystal','sonar','pulse'].includes(patch.sound)?patch.sound:old.sound;
    const volume=patch.volume===undefined?old.volume:Math.max(0,Math.min(100,Number(patch.volume)||0));
    const desktopNotifications=typeof patch.desktopNotifications==='boolean'?patch.desktopNotifications:old.desktopNotifications!==false;
    state.settings={...old,sound,volume,desktopNotifications};
  }
  else if(req.type==='watchChannel'){
    const name=String(req.name||'').toLowerCase();if(!/^[a-z0-9_]{1,25}$/.test(name))throw Error('Неверный логин канала');
    const old=state.watchedChannels||[];if(!old.includes(name)){if(old.length>=20)throw Error('Можно добавить не больше 20 каналов');state.watchedChannels=[...old,name];}
  }
  else if(req.type==='unwatchChannel'){state.watchedChannels=(state.watchedChannels||[]).filter(n=>n!==req.name);}
  else if(req.type==='setChannelPaused'){
    const name=String(req.name||'').toLowerCase();if(!/^[a-z0-9_]{1,25}$/.test(name))throw Error('Неверный канал');
    state.pausedChannels=(state.pausedChannels||[]).filter(n=>n!==name);if(req.paused)state.pausedChannels.push(name);
  }
  else if(req.type==='hidePanelItems'){const ids=new Set(Array.isArray(req.ids)?req.ids:[]);const valid=state.recent.filter(r=>ids.has(r.id)&&r.channelName===req.channelName).map(r=>r.id);state.panelHidden=[...new Set([...(state.panelHidden||[]),...valid])];}
  else if(req.type==='remove'){state.pendingReview=(state.pendingReview||[]).filter(r=>r.id!==req.id);state.recent=state.recent.filter(r=>r.id!==req.id);state.panelHidden=(state.panelHidden||[]).filter(id=>id!==req.id);if(state.draft?.recordId===req.id)state.draft=null;}
  else if(req.type==='markReviewed'){retainPendingInHistory(state,req.id);state.pendingReview=(state.pendingReview||[]).filter(r=>r.id!==req.id);}
  else if(req.type==='saveDraft'){state.draft=req.draft;}
  else if(req.type==='clearDraftIfMatches'){if(state.draft?.recordId===req.recordId&&state.draft.text===req.expectedDraftText){state.draft=null;retainPendingInHistory(state,req.recordId);state.pendingReview=(state.pendingReview||[]).filter(r=>r.id!==req.recordId);}}
  else if(req.type==='clear'){state.total=0;state.byChannel={};state.recent=[];state.pendingReview=[];state.draft=null;state.panelHidden=[];}
  else throw Error('Неизвестная операция');
  await chrome.storage.local.set({[KEY]:state});return {ok:true,state};
}
function loginOf(r){const x=r.login||r.name||'';return /^[a-z0-9_]{1,25}$/i.test(x)?x.toLowerCase():null;}
async function openReport(recordId){
  const state=await read(), record=state.recent.find(r=>r.id===recordId)||(state.pendingReview||[]).find(r=>r.id===recordId);
  if(!record)return {ok:true,stage:'missing',message:'Запись не найдена. Текст скопирован.'};
  const channel=String(record.channelName||'').toLowerCase();
  const tabs=await chrome.tabs.query({url:['https://www.twitch.tv/*','https://m.twitch.tv/*']});
  const matches=tabs.filter(t=>{try{const parts=new URL(t.url).pathname.split('/').filter(Boolean);return ((parts[0]==='popout'||parts[0]==='moderator')?parts[1]:parts[0]||'').toLowerCase()===channel;}catch{return false;}});
  for(const tab of matches){
    try{const result=await chrome.tabs.sendMessage(tab.id,{target:'report-helper',action:'openReport',recordId});
      if(result?.stage && !['missing','notfound'].includes(result.stage)){await chrome.tabs.update(tab.id,{active:true});await chrome.windows.update(tab.windowId,{focused:true});return {ok:true,...result};}
    }catch(e) { /* Page may need to be reloaded after updating the extension. */ }
  }
  const login=loginOf(record);
  if(login){await chrome.tabs.create({url:'https://www.twitch.tv/'+login});return {ok:true,stage:'profile',message:'Текст скопирован. Исходный чат недоступен — открыт профиль автора; откройте жалобу вручную. Исходное сообщение может не прикрепиться.'};}
  return {ok:true,stage:'missing',message:'Текст скопирован. Исходный чат недоступен, логин автора не определён: откройте жалобу вручную.'};
}
chrome.runtime.onMessage.addListener((req,sender,sendResponse)=>{
  if(req.target==='sound-player'||req.target==='report-helper')return false;
  if(req.type==='chatterinoStatus'){getChatterinoStatus().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e)}));return true;}
  if(req.type==='chatterinoChanged'){sendResponse({ok:false});return false;}
  if(req.type==='cwNativeToggle'){if(sender.url!==chrome.runtime.getURL('popup.html')){sendResponse({ok:false});return false;}setNativeEnabled(!!req.enabled).then(()=>sendResponse({ok:true})).catch(e=>sendResponse({ok:false,error:String(e)}));return true;}
  if(req.type==='getMonitorStatus'){getMonitorStatus().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e)}));return true;}
  if(req.type==='openReport'){
    (async()=>{let result;try{result=await openReport(req.recordId);}catch(e){result={ok:false,error:String(e)};}
      if(req.clearDraftAfterCopy===true&&typeof req.expectedDraftText==='string'){
        const job=queue.then(()=>processRequest({type:'clearDraftIfMatches',recordId:req.recordId,expectedDraftText:req.expectedDraftText}));queue=job.catch(()=>{});await job;
      }return result;})().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e)}));return true;
  }
  queue=queue.then(()=>processRequest(req)).then(result=>{if(['watchChannel','unwatchChannel','setChannelPaused'].includes(req.type))scheduleSync();sendResponse(result);}).catch(err=>sendResponse({ok:false,error:String(err)}));
  return true;
});

// Read-only anonymous Twitch IRC connection, independent of rendering in the tab.
// Twitch may change or restrict anonymous access; the on-page observer remains a fallback.
let irc=null, desired=new Set(), joined=new Set(), attempted=new Set();
let handshake=false, retryTimer=null, heartbeat=null, syncTimer=null, joinTimer=null, awaitingPong=false;
let connectionStarted=0;const joinStarted=new Map();
let failures=0, hasFailed=false;
function tabChannel(tab){
  try{const u=new URL(tab.url||tab.pendingUrl||'');if(!['www.twitch.tv','m.twitch.tv'].includes(u.hostname))return null;
    const p=u.pathname.toLowerCase().split('/').filter(Boolean);let n=null;
    if(p.length===1)n=p[0];else if(p[0]==='popout'&&p.length===3&&p[2]==='chat')n=p[1];else if(p[0]==='moderator'&&p.length===2)n=p[1];
    return /^[a-z0-9_]{1,25}$/.test(n||'')?n:null;
  }catch{return null;}
}
function scheduleSync(){clearTimeout(syncTimer);syncTimer=setTimeout(()=>syncMonitor().catch(e=>console.warn('Синхронизация чатов:',e.message)),200);}
function closeIRC(){
  clearTimeout(retryTimer);retryTimer=null;clearInterval(heartbeat);heartbeat=null;clearTimeout(joinTimer);joinTimer=null;
  const old=irc;irc=null;handshake=false;awaitingPong=false;joined.clear();attempted.clear();joinStarted.clear();if(old)try{old.close();}catch{}
}
async function syncMonitor(){
  const [state,tabs]=await Promise.all([read(),chrome.tabs.query({url:['https://www.twitch.tv/*','https://m.twitch.tv/*']})]);
  const open=new Set(tabs.map(tabChannel).filter(Boolean));
  const paused=new Set(state.pausedChannels||[]);
  desired=new Set((state.watchedChannels||[]).filter(n=>open.has(n)&&!paused.has(n)));
  if(!desired.size){closeIRC();failures=0;hasFailed=false;return;}
  for(const n of [...attempted])if(!desired.has(n)){
    if(irc?.readyState===WebSocket.OPEN)irc.send('PART #'+n);
    attempted.delete(n);joined.delete(n);joinStarted.delete(n);
  }
  if(!irc&&!retryTimer)connectIRC();else pumpJoins();
}
function pumpJoins(){
  if(joinTimer||!irc||irc.readyState!==WebSocket.OPEN||!handshake)return;
  const next=[...desired].find(n=>!attempted.has(n));if(!next)return;
  attempted.add(next);joinStarted.set(next,Date.now());irc.send('JOIN #'+next);
  joinTimer=setTimeout(()=>{joinTimer=null;pumpJoins();},700);
}
function reconnect(){
  if(!desired.size||retryTimer)return;
  hasFailed=true;const delay=Math.min(60000,1000*2**Math.min(failures++,6))*(0.8+Math.random()*0.4);
  retryTimer=setTimeout(()=>{retryTimer=null;syncMonitor().catch(()=>reconnect());},delay);
}
function connectIRC(){
  if(irc||!desired.size)return;
  const ws=new WebSocket('wss://irc-ws.chat.twitch.tv:443');irc=ws;connectionStarted=Date.now();awaitingPong=false;
  ws.onopen=()=>{if(irc!==ws)return;
    ws.send('PASS SCHMOOPIIE');ws.send('NICK justinfan'+Math.floor(100000+Math.random()*900000));ws.send('CAP REQ :twitch.tv/tags twitch.tv/commands');
    heartbeat=setInterval(()=>{if(irc!==ws||ws.readyState!==WebSocket.OPEN)return;
      const now=Date.now();
      if(awaitingPong||(!handshake&&now-connectionStarted>30000)||[...joinStarted].some(([n,t])=>desired.has(n)&&!joined.has(n)&&now-t>40000)){ws.close();return;}
      awaitingPong=true;ws.send('PING :chat-watch');
    },20000);
  };
  ws.onmessage=e=>{if(irc!==ws||typeof e.data!=='string')return;
    for(const line of e.data.split(/\r?\n/)){
      if(line.startsWith('PING ')){ws.send('PONG '+line.slice(5));continue;}
      if(/(?:^| )PONG(?: |$)/.test(line)){awaitingPong=false;continue;}
      if(/\s001\s/.test(line)){handshake=true;failures=0;hasFailed=false;pumpJoins();continue;}
      const join=line.match(/(?:\sJOIN\s|\sROOMSTATE\s)#([a-z0-9_]+)/i);if(join&&desired.has(join[1].toLowerCase())){joined.add(join[1].toLowerCase());continue;}
      const msg=line.match(/^@([^ ]+) :([a-z0-9_]+)![^ ]+ PRIVMSG #([a-z0-9_]+) :(.*)$/i);
      if(!msg)continue;
      const channel=msg[3].toLowerCase();let text=msg[4].replace(/^\x01ACTION (.*)\x01$/,'$1');
      if(!desired.has(channel)||!text||!TwitchReportDetector.candidate(text))continue;
      const tags=Object.fromEntries(msg[1].split(';').map(t=>{let i=t.indexOf('=');return [t.slice(0,i),t.slice(i+1).replace(/\\s/g,' ').replace(/\\:/g,';').replace(/\\\\/g,'\\')];}));
      const id=tags.id||null,login=msg[2].toLowerCase();const at=Number(tags['tmi-sent-ts'])||Date.now();
      const item={id:id?'irc:'+id:crypto.randomUUID(),messageId:id,name:tags['display-name']||login,login,text,channelName:channel,channel:'https://www.twitch.tv/'+channel,detectedAt:at};
      queue=queue.then(()=>desired.has(channel)?processRequest({type:'add',item}):null).catch(e=>console.warn('Не удалось сохранить совпадение:',e.message));
    }
  };
  ws.onerror=()=>{};
  ws.onclose=()=>{if(irc!==ws)return;irc=null;handshake=false;joined.clear();attempted.clear();joinStarted.clear();awaitingPong=false;clearInterval(heartbeat);heartbeat=null;clearTimeout(joinTimer);joinTimer=null;reconnect();};
}
async function getMonitorStatus(){
  const [state,tabs]=await Promise.all([read(),chrome.tabs.query({url:['https://www.twitch.tv/*','https://m.twitch.tv/*']})]);
  const open=new Set(tabs.map(tabChannel).filter(Boolean)),channels={};
  for(const n of state.watchedChannels||[]){
    channels[n]=(state.pausedChannels||[]).includes(n)?'paused':!open.has(n)?'closed':joined.has(n)?'connected':hasFailed?'reconnecting':irc?'connecting':'unavailable';
  }
  scheduleSync();return {ok:true,channels};
}
chrome.tabs.onUpdated.addListener(scheduleSync);chrome.tabs.onRemoved.addListener(scheduleSync);
chrome.runtime.onStartup.addListener(scheduleSync);chrome.runtime.onInstalled.addListener(scheduleSync);
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='chat-watch-sync')scheduleSync();});
chrome.alarms.create('chat-watch-sync',{periodInMinutes:1});
scheduleSync();

// Chatterino+ second source via a narrowly scoped local native-messaging host.
let cwPort=null,cwEnabled=false,cwSeen=null,cwBusy=false,cwPending=false,cwTimer=null,cwRetry=null,cwTimeout=null;
let cwStatus='disabled',cwActive=null,cwFailures=0;
async function getChatterinoStatus(){return {ok:true,status:cwStatus,active:cwActive,enabled:cwEnabled};}
async function setNativeEnabled(enabled){
  await chrome.storage.local.set({cwNativeEnabled:enabled});cwEnabled=enabled;
  clearTimeout(cwRetry);clearTimeout(cwTimeout);clearInterval(cwTimer);cwRetry=cwTimeout=cwTimer=null;
  const old=cwPort;cwPort=null;cwPending=false;cwActive=null;if(old)try{old.disconnect();}catch{}
  if(enabled){cwStatus='connecting';connectNative();}else cwStatus='disabled';
}
function scheduleNativeRetry(){
  if(!cwEnabled||cwRetry)return;
  const delay=Math.min(60000,5000*Math.pow(2,Math.min(cwFailures++,4)));
  cwRetry=setTimeout(()=>{cwRetry=null;connectNative();},delay);
}
function sendNativeRead(){
  if(!cwPort||cwPending||!cwEnabled)return;cwPending=true;
  try{cwPort.postMessage({type:'read'});cwTimeout=setTimeout(()=>{if(cwPort)cwPort.disconnect();},12000);}catch{cwPending=false;if(cwPort)cwPort.disconnect();}
}
function connectNative(){
  if(!cwEnabled||cwPort)return;let port;
  try{port=chrome.runtime.connectNative('com.chatwatch.chatterino');}catch{cwStatus='host-error';scheduleNativeRetry();return;}
  cwPort=port;cwStatus='connecting';
  port.onMessage.addListener(async msg=>{
    if(port!==cwPort)return;clearTimeout(cwTimeout);cwTimeout=null;cwPending=false;cwFailures=0;
    if(!msg||msg.ok!==true){cwStatus=msg?.error==='missing'?'feed-missing':'feed-error';cwActive=null;return;}
    if(!msg.feed||msg.feed.version!==1||!Array.isArray(msg.feed.events)||msg.feed.events.length>1000||!Number.isFinite(msg.mtime)){cwStatus='feed-error';return;}
    cwActive=Array.isArray(msg.feed.channels)?msg.feed.channels.filter(x=>x&&x.active===true).length:null;
    cwStatus=Date.now()-msg.mtime<30000?'active':'stale';
    try{await processFeed(msg.feed);}catch(e){cwStatus='feed-error';console.warn('Chatterino feed:',e.message);}
  });
  port.onDisconnect.addListener(()=>{
    const why=chrome.runtime.lastError?.message||'';if(port!==cwPort)return;
    cwPort=null;cwPending=false;clearInterval(cwTimer);clearTimeout(cwTimeout);cwTimer=cwTimeout=null;
    if(cwEnabled){cwStatus='host-error';console.warn('Локальный мост недоступен:',why);scheduleNativeRetry();}
  });
  sendNativeRead();cwTimer=setInterval(sendNativeRead,3000);
}
async function processFeed(data){
  if(cwBusy)return;cwBusy=true;
  try{
    if(!cwSeen){const stored=await chrome.storage.local.get('cwBridgeSeen');
      if(!Array.isArray(stored.cwBridgeSeen)){
        // First setup: establish a baseline rather than reporting old messages.
        const ids=data.events.map(e=>e?.id).filter(x=>typeof x==='string'&&x.length<=128).slice(-1000);
        cwSeen=new Set(ids);await chrome.storage.local.set({cwBridgeSeen:ids});return;
      }cwSeen=new Set(stored.cwBridgeSeen);
    }
    const state=await read();const watched=new Set(state.watchedChannels||[]);
    for(const ev of data.events){
      if(!ev||typeof ev.id!=='string'||!ev.id||ev.id.length>128||cwSeen.has(ev.id))continue;
      const channel=String(ev.channel||'').toLowerCase(),login=String(ev.login||'').toLowerCase(),text=ev.text,name=ev.name;
      if(!/^[a-z0-9_]{1,25}$/.test(channel)||!/^[a-z0-9_]{1,25}$/.test(login)||typeof text!=='string'||text.length>4000||typeof name!=='string'||name.length>100)continue;
      if(watched.has(channel)&&!(state.pausedChannels||[]).includes(channel)&&TwitchReportDetector.candidate(text)){
        const item={source:'chatterino',id:'irc:'+ev.id,messageId:ev.id,login,name:name||login,text,channelName:channel,channel:'https://www.twitch.tv/'+channel,detectedAt:typeof ev.time==='number'&&ev.time>0?ev.time:Date.now()};
        const job=queue.then(()=>processRequest({type:'add',item}));queue=job.catch(e=>console.warn('Chatterino:',e.message));await job;
      }
      cwSeen.add(ev.id);
    }
    const ids=[...cwSeen].slice(-5000);cwSeen=new Set(ids);await chrome.storage.local.set({cwBridgeSeen:ids});
  }finally{cwBusy=false;}
}
async function initializeNative(){const v=await chrome.storage.local.get('cwNativeEnabled');if(v.cwNativeEnabled===true){cwEnabled=true;connectNative();}}
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='chat-watch-sync'&&cwEnabled&&!cwPort){clearTimeout(cwRetry);cwRetry=null;connectNative();}});
initializeNative();
