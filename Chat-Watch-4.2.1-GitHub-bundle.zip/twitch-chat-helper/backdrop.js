
(()=>{
 const captions={
  bratishkinoff:['«Я со всего могу выпасть.»','«Я быдло, что мне делать?»','«Или хлеб падает.»','«Я во всё играю.»','«Как аквариум.»','«Пытаюсь вспомнить.»','«Я такой написал, забил хуй»'],
  t2x2:['«Прости галустян :(»','«Короче до завтра блин ❤️»','«Привет ребят, сегодня отдыхаю.»','«Новые битые огурцы!»','«Дома! Ура!»','«🫵 писька»','«Six seven!»','«Давайте жить дружно»','«Дедушка, не надо!»','«Кто съел мои куки-болз?»'],
  stintik:['«Бля, мне инет отъебнуло»','«стрим в 15:00. Прикиньте?»','«Ладно, извините.»','«Не смешно, мне так ходить»','«Я за это 2000 отдал»','«Бяу»','«Ты послал нахуй банан»','«Я просто банан, блять»'],
  drakeoffc:['«я проснулся 👍»','«дуров верни стену»','«всем быть 👍»','«стримс в 17:00 😉»','«Шаманы! Стоим!»','«Хорошо сработали!»'],
  mazellovvv:['«Я не участник 89-го блять!»','«Всем ку»','«Я УХОЖУ С ТВИЧА 😭»','«Че нормально я покараокил?»','«Должно быть весело!»'],
  '5opka':['«42, братуха!»','«Коме бацк на Твэч»','«Да, я крутой, ха-ха.»','«Сегодня — нет.»']
 };
 const backdrop=document.querySelector('.streamer-backdrop');
 const reduce=matchMedia('(prefers-reduced-motion: reduce)');
 const cards=[...document.querySelectorAll('.streamer-card')];
 const random=(min,max)=>min+Math.random()*(max-min);
 const pick=items=>items[Math.floor(Math.random()*items.length)];
 const edges=['left','right','top','bottom'];
 function point(edge,w,h,cw,ch){
  const m=35; // Rotation and shadow must also clear the frame.
  if(edge==='left')return {x:-cw-m,y:random(0,Math.max(1,h-ch))};
  if(edge==='right')return {x:w+m,y:random(0,Math.max(1,h-ch))};
  if(edge==='top')return {x:random(-cw*.3,Math.max(1,w-cw*.7)),y:-ch-m};
  return {x:random(-cw*.3,Math.max(1,w-cw*.7)),y:h+m};
 }
 cards.forEach((card,i)=>{
  const lines=captions[card.dataset.streamer],label=card.querySelector('.streamer-caption');
  let index=0,animation=null;label.textContent=lines[index];
  function travel(initial=false){
   if(reduce.matches)return;
   const w=backdrop.clientWidth,h=backdrop.clientHeight,cw=card.offsetWidth,ch=card.offsetHeight;
   const start=pick(edges),end=pick(edges.filter(e=>e!==start));
   const from=point(start,w,h,cw,ch),to=point(end,w,h,cw,ch);
   // Cross between distant corners while keeping the whole card within the frame.
   const margin=16, minX=margin, maxX=Math.max(minX,w-cw-margin);
   const minY=margin, maxY=Math.max(minY,h-ch-margin);
   let sideX=Math.random()<.5?0:1, sideY=Math.random()<.5?0:1;
   const interior=Array.from({length:2},(_,j)=>{
    if(j){sideY=1-sideY;sideX=1-sideX;}
    const jitterX=(maxX-minX)*.12,jitterY=(maxY-minY)*.09;
    return {x:sideX?random(maxX-jitterX,maxX):random(minX,minX+jitterX),
      y:sideY?random(maxY-jitterY,maxY):random(minY,minY+jitterY)};
   });
   const route=[from,...interior,to];let distance=0;const offsets=[0];
   for(let j=1;j<route.length;j++){distance+=Math.hypot(route[j].x-route[j-1].x,route[j].y-route[j-1].y);offsets.push(distance);}
   const duration=distance/random(52,65)*1000;
   const frames=route.map((pt,j)=>({transform:`translate(${pt.x}px,${pt.y}px) rotate(${random(-2,2)}deg)`,offset:offsets[j]/distance}));
   animation=card.animate(frames,{duration,easing:'linear',fill:'both'});
   if(initial)animation.currentTime=duration*random(.12,.38);
   const completed=animation;completed.onfinish=()=>{completed.cancel();if(reduce.matches)return;index=(index+1)%lines.length;label.textContent=lines[index];travel();};
  }
  function applyMotion(){
   if(animation){animation.onfinish=null;animation.cancel();animation=null;}
   if(reduce.matches){const w=backdrop.clientWidth,h=backdrop.clientHeight;card.style.transform=`translate(${Math.max(0,w-card.offsetWidth)*(i%2)}px,${Math.max(0,h-card.offsetHeight)*((i+1)/(cards.length+1))}px)`;}
   else{card.style.transform='';travel(true);}
  }
  reduce.addEventListener('change',applyMotion);applyMotion();
 });
})();
