-- Local-only rotating feed; no HTTP and no chat posts.
local channels, handles, buffer = {}, {}, {}
local dirty = true
local ticks = 0
local function valid(n) return type(n) == 'string' and #n >= 1 and #n <= 25 and n:match('^[a-z0-9_]+$') ~= nil end
local function say(ch, text) pcall(function() ch:add_system_message('Chat Watch: ' .. text) end) end
local function load_channels()
    local f = io.open('channels.txt','r')
    if f then for line in f:lines() do if valid(line) and #channels < 20 then table.insert(channels,line) end end f:close() end
end
local function save_channels()
    local f,err=io.open('channels.txt','w');if not f then return false,err end
    for _,n in ipairs(channels) do f:write(n,'\n') end f:close();return true
end
local function quoted(s)
    return '"' .. tostring(s):gsub('[%z\1-\31\\"]',function(c)
        if c=='"' then return '\\"' elseif c=='\\' then return '\\\\' end
        return string.format('\\u%04x',string.byte(c))
    end) .. '"'
end
local function emit()
    local lines={}
    for _,m in ipairs(buffer) do
        table.insert(lines,'{"id":'..quoted(m.id)..',"login":'..quoted(m.login)..',"name":'..quoted(m.name)..',"text":'..quoted(m.text)..',"channel":'..quoted(m.channel)..',"time":'..tostring(m.time)..'}')
    end
    local f,err=io.open('feed.json','w');if not f then c2.log(c2.LogLevel.Warning,'Feed write error:',tostring(err));return end
    local states={}
    for _,n in ipairs(channels) do table.insert(states,'{"name":'..quoted(n)..',"active":'..tostring(handles[n]~=nil)..'}') end
    f:write('{"version":1,"channels":[',table.concat(states,','),'],"events":[',table.concat(lines,','),']}');f:close();dirty=false
end
local function ensure_channel(n)
    local ok,ch=pcall(c2.Channel.by_name,n)
    if not ok or not ch then
        if handles[n] then pcall(function() handles[n].hdl:disconnect() end);handles[n]=nil end
        return
    end
    if handles[n] then
        local validOld,still=pcall(function() return handles[n].channel:is_valid() end)
        if validOld and still then return end
        pcall(function() handles[n].hdl:disconnect() end);handles[n]=nil
    end
    local ok2,hdl=pcall(function() return ch:on_message_appended(function(msg)
        local ok3,id,login,name,text,ts=pcall(function() return msg.id,msg.login_name,msg.display_name,msg.message_text,msg.timestamp end)
        if not ok3 or type(id)~='string' or id=='' or type(login)~='string' or not valid(login:lower()) or type(text)~='string' or text=='' then return end
        if type(name)~='string' or name=='' then name=login end
        if #text>4000 then return end
        buffer[#buffer+1]={id=id,login=login:lower(),name=name,text=text,channel=n,time=type(ts)=='number' and ts or 0}
        if #buffer>1000 then table.remove(buffer,1) end
        dirty=true
    end) end)
    if ok2 then handles[n]={channel=ch,hdl=hdl} end
end
local function cycle()
    ticks=ticks+1
    for _,n in ipairs(channels) do ensure_channel(n) end
    if dirty or ticks%5==0 then emit() end
    c2.later(cycle,2000)
end
local function find_channel(n) for i,x in ipairs(channels) do if x==n then return i end end end
c2.register_command('/cwadd',function(ctx)
    local ok,n=pcall(function() return ctx.channel:get_name():lower() end)
    local typeOk,kind=pcall(function() return ctx.channel:get_type() end)
    if not ok or not valid(n) or not typeOk or kind~=c2.ChannelType.Twitch then say(ctx.channel,'Откройте обычный чат канала Twitch.');return end
    if find_channel(n) then say(ctx.channel,'Канал уже добавлен.');return end
    if #channels>=20 then say(ctx.channel,'Лимит — 20 каналов.');return end
    channels[#channels+1]=n;local saved,err=save_channels();if not saved then table.remove(channels);say(ctx.channel,'Не удалось сохранить список: '..tostring(err));return end
    ensure_channel(n);say(ctx.channel,'Канал добавлен во второй источник. Данные остаются локально.')
end)
c2.register_command('/cwremove',function(ctx)
    local ok,n=pcall(function() return ctx.channel:get_name():lower() end);if not ok then return end
    local i=find_channel(n);if not i then say(ctx.channel,'Канал не добавлен.');return end
    table.remove(channels,i);local saved,err=save_channels();if not saved then table.insert(channels,i,n);say(ctx.channel,'Не удалось сохранить список: '..tostring(err));return end
    if handles[n] then pcall(function() handles[n].hdl:disconnect() end);handles[n]=nil end
    say(ctx.channel,'Канал удалён из второго источника.')
end)
c2.register_command('/cwinfo',function(ctx)
    local active=0;for _ in pairs(handles) do active=active+1 end
    say(ctx.channel,'Выбрано каналов: '..#channels..'; подключено в Chatterino: '..active..'. Локальный файл feed.json обновляется каждые 2–10 секунд.')
end)
load_channels();cycle()
