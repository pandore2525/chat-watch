# Chat Watch native host: reads only the existing Chatterino+ plugin feed.
# Standard output is reserved exclusively for Chrome's native messaging protocol.
$ErrorActionPreference = 'Stop'
$stdin = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
$utf8 = New-Object System.Text.UTF8Encoding($false)
$feedPath = Join-Path $env:APPDATA 'Chatterino by Rish\Plugins\chat_watch\data\feed.json'
function Read-Exact([int]$length) {
    $bytes = New-Object byte[] $length
    $offset = 0
    while ($offset -lt $length) {
        $n = $stdin.Read($bytes, $offset, $length - $offset)
        if ($n -eq 0) { return $null }
        $offset += $n
    }
    return ,$bytes
}
function Respond([string]$json) {
    $bytes = $utf8.GetBytes($json)
    $header = [BitConverter]::GetBytes([uint32]$bytes.Length)
    $stdout.Write($header, 0, 4)
    $stdout.Write($bytes, 0, $bytes.Length)
    $stdout.Flush()
}
while ($true) {
    try {
        $header = Read-Exact 4
        if ($null -eq $header) { break }
        $length = [BitConverter]::ToUInt32($header, 0)
        if ($length -lt 2 -or $length -gt 4096) { break }
        $body = Read-Exact ([int]$length)
        if ($null -eq $body) { break }
        $request = $utf8.GetString($body) | ConvertFrom-Json
        if ($request.type -ne 'read') { Respond '{"ok":false,"error":"request"}'; continue }
        if (-not [System.IO.File]::Exists($feedPath)) { Respond '{"ok":false,"error":"missing"}'; continue }
        try {
            $info = New-Object System.IO.FileInfo($feedPath)
            if ($info.Length -gt 900000) { Respond '{"ok":false,"error":"size"}'; continue }
            # The plugin can write simultaneously; read errors or a partial JSON are retried.
            $text = [System.IO.File]::ReadAllText($feedPath, $utf8).TrimStart([char]0xFEFF)
            $null = $text | ConvertFrom-Json
            $mtime = [long]([DateTimeOffset]::new($info.LastWriteTimeUtc).ToUnixTimeMilliseconds())
            $answer = '{"ok":true,"mtime":' + $mtime + ',"feed":' + $text + '}'
            if ($utf8.GetByteCount($answer) -gt 1000000) { Respond '{"ok":false,"error":"size"}'; continue }
            Respond $answer
        } catch { Respond '{"ok":false,"error":"read"}' }
    } catch { break }
}
