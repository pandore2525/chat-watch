$ErrorActionPreference = 'Stop'
try {
  $key = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.chatwatch.chatterino'
  if (Test-Path $key) { Remove-Item -Path $key -Force }
  $dest = Join-Path $env:LOCALAPPDATA 'ChatWatchNative'
  if (Test-Path $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
  Write-Host 'Native bridge removed. Chatterino+, its feed and extension history were not deleted.'
} catch { Write-Host ('Removal failed: ' + $_.Exception.Message); exit 1 }
