$ErrorActionPreference = 'Stop'
try {
  Write-Host 'Chat Watch - install local Chrome bridge for the current Windows user'
  Write-Host 'Copy the extension ID from the popup or chrome://extensions.'
  $id = (Read-Host 'Extension ID').Trim().ToLowerInvariant()
  if ($id -cnotmatch '^[a-p]{32}$') { throw 'Invalid extension ID. Expected 32 lowercase letters a-p.' }
  $dest = Join-Path $env:LOCALAPPDATA 'ChatWatchNative'
  New-Item -ItemType Directory -Path $dest -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'host.ps1') -Destination $dest -Force
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'host.cmd') -Destination $dest -Force
  $manifestPath = Join-Path $dest 'com.chatwatch.chatterino.json'
  $manifest = @{name='com.chatwatch.chatterino';description='Chat Watch local Chatterino+ feed';path=(Join-Path $dest 'host.cmd');type='stdio';allowed_origins=@("chrome-extension://$id/")} | ConvertTo-Json -Depth 4
  [System.IO.File]::WriteAllText($manifestPath, $manifest, (New-Object System.Text.UTF8Encoding($false)))
  $key = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.chatwatch.chatterino'
  New-Item -Path $key -Force | Out-Null
  Set-Item -Path $key -Value $manifestPath
  Write-Host 'Installed for Google Chrome. Open extension and click Connect bridge.'
  Write-Host 'Only the selected extension ID is allowed. No administrator rights needed.'
} catch { Write-Host ('Installation failed: ' + $_.Exception.Message); exit 1 }
